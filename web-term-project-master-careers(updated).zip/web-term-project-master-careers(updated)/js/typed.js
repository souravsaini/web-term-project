let typed = new Typed(".typed", {
  strings: ["Build", "Solve", "Support", "Excel"],
  typeSpeed: 100,
  backSpeed: 60,
  loop: true,
});
